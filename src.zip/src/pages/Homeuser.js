import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default function Home() {
    const [employee, setEmployee] = useState(null);
    const [searchId, setSearchId] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const { id } = useParams();

    useEffect(() => {
        if (id) {
            loadEmployeeById(id);
        } else if (searchId) {
            loadEmployeeById(searchId);
        } else {
            setEmployee(null);
        }
    }, [id, searchId]);

    const loadEmployeeById = async (employeeId) => {
        try {
            setLoading(true);
            const result = await axios.get(`http://localhost:8080/employee/${employeeId}`);
            setEmployee(result.data);
            setError(null);
        } catch (error) {
            console.error("Employee not found:", error.message);
            setEmployee(null); 
            setError("Employee not found");
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = () => {
        loadEmployeeById(searchId);
    };

    return (
        <div className='container'>
            <div className='py-4'>
                <div className="mb-3">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Enter employee ID"
                        value={searchId}
                        onChange={(e) => setSearchId(e.target.value)}
                    />
                    <button className="btn btn-primary mt-2" onClick={handleSearch}>
                        Search
                    </button>
                </div>
                {loading && <p>Loading...</p>}
                {error && <p className="text-danger">{error}</p>}
                {employee && !loading && !error && (
                    <table className="table border shadow">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Department</th>
                                <th scope="col">Income</th>
                                <th scope="col">Address</th>
                                <th scope="col">Designation</th>
                                <th scope="col">Gender</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{employee.name}</td>
                                <td>{employee.dept}</td>
                                <td>{employee.income}</td>
                                <td>{employee.address}</td>
                                <td>{employee.designation}</td>
                                <td>{employee.gender}</td>
                            </tr>
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
}
