import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const navigate = useNavigate();
  const [userType, setUserType] = useState('');

  const handleLogin = () => {
    if (userType === 'admin') {
      navigate('/logindept');
    } else if (userType === 'employee') {
      navigate('/Homeuser');
    }
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card mt-5">
            <div className="card-body">
              <h3 className="text-center mb-4">Select User Type</h3>
              <div className="form-group">
                <label className="radio-label">
                  <input
                    type="radio"
                    value="admin"
                    checked={userType === 'admin'}
                    onChange={() => setUserType('admin')}
                  />
                  Admin
                </label>
                <label className="radio-label">
                  <input
                    type="radio"
                    value="employee"
                    checked={userType === 'employee'}
                    onChange={() => setUserType('employee')}
                  />
                  Employee
                </label>
              </div>
              <div className="form-group text-center">
                <button onClick={handleLogin} className="btn btn-primary" id="btn">
                  Login
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
